# shelltris
🕹️ Terminal tetris game
![t01](./previews/01.png)
![t02](./previews/02.png)
![t03](./previews/03.png)

## Installation
Ive not release binary yet so build from source more prefered :)